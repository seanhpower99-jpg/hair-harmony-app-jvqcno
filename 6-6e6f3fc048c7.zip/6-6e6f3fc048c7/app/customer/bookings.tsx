import React, { useContext } from 'react';
import { View, Text, FlatList } from 'react-native';
import { AuthContext } from '../../context/AuthContext';
import { mockBookings } from '../../data/mockData';
import { commonStyles } from '../../styles/commonStyles';

export default function CustomerBookingsScreen() {
  const auth = useContext(AuthContext);
  if (!auth || !auth.user) return null;
  const { user } = auth;

  const myBookings = mockBookings.filter(b => b.customerId === user.id);

  return (
    <View style={commonStyles.container}>
      <Text style={commonStyles.title}>My Bookings</Text>
      {myBookings.length === 0 ? (
        <Text style={commonStyles.text}>No bookings yet.</Text>
      ) : (
        <FlatList
          data={myBookings}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={commonStyles.card}>
              <Text style={commonStyles.cardTitle}>{item.service}</Text>
              <Text style={commonStyles.text}>Date: {item.date}</Text>
              <Text style={commonStyles.text}>Hairdresser: {item.hairdresserName}</Text>
              <Text style={commonStyles.text}>Status: {item.status}</Text>
            </View>
          )}
        />
      )}
    </View>
  );
}
